import SwiftUI

@main
struct AttributionTestAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
