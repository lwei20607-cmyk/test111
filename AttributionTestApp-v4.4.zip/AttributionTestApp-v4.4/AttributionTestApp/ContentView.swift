import SwiftUI
import UIKit

struct ContentView: View {
    @AppStorage("worker_base_url") private var workerBaseURL = "https://attribution-system.lwei20607.workers.dev"
    @AppStorage("short_code") private var shortCode = ""
    @AppStorage("event_type") private var eventType = "app_registration"
    @AppStorage("currency") private var currency = "USD"
    @AppStorage("h5_legacy_fp") private var h5LegacyFingerprint = ""
    @AppStorage("h5_v2_fp") private var h5V2Fingerprint = ""
    @AppStorage("h5_network_ua") private var h5NetworkUserAgent = ""

    @State private var installID = KeychainStore.shared.loadOrCreateInstallID()
    @State private var mode: AttributionMode = .fingerprintOnly
    @State private var algorithm: FingerprintAlgorithm = .crossSurfaceV2
    @State private var amountText = "0"
    @State private var isSending = false
    @State private var logText = "Ready."
    @State private var showResetAlert = false
    @State private var didSendAutomaticOpenEvent = false
    @State private var shortCodeCapturedThisLaunch = false

    private var selected: FingerprintResult { algorithm.result }
    private var legacy: FingerprintResult { FingerprintLab.legacyApprox }
    private var v2: FingerprintResult { FingerprintLab.crossSurfaceV2 }
    private var installIdentityHash: String { AttributionClient.sha256Hex(installID) }
    private var amount: Double { Double(amountText) ?? 0 }

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Device / hash verification")) {
                    labeledValue("Model identifier", DeviceInfo.modelIdentifier)
                    labeledValue("iOS", UIDevice.current.systemVersion)
                    labeledValue("JS32 hash self-test", FingerprintLab.hashSelfTestPassed ? "PASS" : "FAIL")
                    labeledValue("Self-test result", FingerprintLab.hashSelfTestHash)
                    Text("The self-test verifies only that Swift reproduces the same JS 32-bit hash. It does not prove that Safari and App expose identical input fields.")
                        .font(.footnote).foregroundColor(.secondary)
                }

                Section(header: Text("Algorithm A — current H5 layout experiment")) {
                    labeledValue("Algorithm ID", legacy.algorithmID)
                    labeledValue("App canonical", legacy.canonicalString)
                    labeledValue("App HW result", legacy.fingerprint)
                    TextField("Paste H5 legacy HW result", text: $h5LegacyFingerprint)
                        .autocapitalization(.allCharacters).disableAutocorrection(true)
                    labeledValue("H5 ↔ App compare", compare(h5LegacyFingerprint, legacy.fingerprint))
                    HStack {
                        Button("Copy A canonical") { UIPasteboard.general.string = legacy.canonicalString }
                            .buttonStyle(.borderless)
                        Spacer()
                        Button("Copy A HW") { UIPasteboard.general.string = legacy.fingerprint }
                            .buttonStyle(.borderless)
                    }
                    Text(legacy.notes).font(.footnote).foregroundColor(.secondary)
                }

                Section(header: Text("Algorithm B — cross-surface v2")) {
                    labeledValue("Algorithm ID", v2.algorithmID)
                    labeledValue("App canonical", v2.canonicalString)
                    labeledValue("App HW result", v2.fingerprint)
                    TextField("Paste H5 v2 HW result", text: $h5V2Fingerprint)
                        .autocapitalization(.allCharacters).disableAutocorrection(true)
                    labeledValue("H5 ↔ App compare", compare(h5V2Fingerprint, v2.fingerprint))
                    HStack {
                        Button("Copy B canonical") { UIPasteboard.general.string = v2.canonicalString }
                            .buttonStyle(.borderless)
                        Spacer()
                        Button("Copy B HW") { UIPasteboard.general.string = v2.fingerprint }
                            .buttonStyle(.borderless)
                    }
                    Text(v2.notes).font(.footnote).foregroundColor(.secondary)
                }

                Section(header: Text("Fingerprint sent to Worker")) {
                    Picker("Algorithm", selection: $algorithm) {
                        ForEach(FingerprintAlgorithm.allCases) { item in Text(item.rawValue).tag(item) }
                    }
                    labeledValue("Selected algorithm ID", selected.algorithmID)
                    labeledValue("Selected hw_fingerprint", selected.fingerprint)
                    Text("IP is intentionally NOT mixed into hw_fingerprint. Worker network/IP fingerprint remains an independent fallback so changing mobile/Wi‑Fi/VPN IP cannot mutate the hardware/environment result.")
                        .font(.footnote).foregroundColor(.secondary)
                }

                Section(header: Text("Automatic App Open event")) {
                    labeledValue("Event", "app_registration")
                    labeledValue("Algorithm", v2.algorithmID)
                    Text("Opening the app automatically sends a new app_registration event with the live V2 fingerprint. A deep link also includes the captured Short Code; a normal first open uses fingerprint matching.")
                        .font(.footnote).foregroundColor(.secondary)
                }

                Section(header: Text("Install diagnostics")) {
                    labeledValue("Install ID", installID)
                    labeledValue("Install ID SHA-256 (diagnostic only)", installIdentityHash)
                    HStack {
                        Button("Copy Install ID") { UIPasteboard.general.string = installID }
                            .buttonStyle(.borderless)
                        Spacer()
                        Button("Reset Install ID") { showResetAlert = true }
                            .buttonStyle(.borderless)
                    }
                }

                Section(header: Text("Worker")) {
                    TextField("Worker base URL", text: $workerBaseURL).autocapitalization(.none).disableAutocorrection(true)
                    Button("Check /health") { Task { await runHealth() } }.disabled(isSending)
                }

                Section(header: Text("Attribution input")) {
                    TextField("Short code", text: $shortCode).autocapitalization(.allCharacters).disableAutocorrection(true)
                    Button("Paste Short Code") {
                        if let value = UIPasteboard.general.string { shortCode = value.trimmingCharacters(in: .whitespacesAndNewlines) }
                    }
                    TextField("H5 browser User-Agent (for network fallback)", text: $h5NetworkUserAgent)
                        .autocapitalization(.none).disableAutocorrection(true)
                    Button("Paste H5 User-Agent") {
                        if let value = UIPasteboard.general.string { h5NetworkUserAgent = value.trimmingCharacters(in: .whitespacesAndNewlines) }
                    }
                    Picker("Send mode", selection: $mode) {
                        ForEach(AttributionMode.allCases) { item in Text(item.rawValue).tag(item) }
                    }
                    Text(modeHelp).font(.footnote).foregroundColor(.secondary)
                }

                Section(header: Text("Event")) {
                    TextField("event_type", text: $eventType).autocapitalization(.none).disableAutocorrection(true)
                    HStack {
                        eventPreset("Set Test", "mobile_sdk_test")
                        Spacer()
                        eventPreset("Set View", "app_view_content")
                    }
                    HStack {
                        eventPreset("Set Register", "app_registration")
                        Spacer()
                        eventPreset("Set Purchase", "app_purchase")
                    }
                    TextField("Amount", text: $amountText).keyboardType(.decimalPad)
                    TextField("Currency", text: $currency).autocapitalization(.allCharacters).disableAutocorrection(true)
                    Button(isSending ? "Sending…" : "Send CURRENT event") { Task { await sendCurrentEvent() } }
                        .disabled(isSending || eventType.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    HStack {
                        Button("Send View now") { Task { await sendNamedEvent("app_view_content", amountOverride: 0) } }
                            .buttonStyle(.borderless).disabled(isSending)
                        Spacer()
                        Button("Send Register now") { Task { await sendNamedEvent("app_registration", amountOverride: 0) } }
                            .buttonStyle(.borderless).disabled(isSending)
                    }
                    Button("Send Purchase now") { Task { await sendNamedEvent("app_purchase", amountOverride: amount) } }
                        .disabled(isSending)
                    Text("The Set buttons only change event_type. The Send … now buttons perform the HTTP request immediately.")
                        .font(.footnote).foregroundColor(.secondary)
                }

                Section(header: Text("Regression")) {
                    Button("Test short_code + selected fingerprint") { Task { await sendWithExplicitMode(.shortCodeAndFingerprint) } }.disabled(isSending)
                    Button("Test selected fingerprint fallback only") { Task { await sendWithExplicitMode(.fingerprintOnly) } }.disabled(isSending)
                    Button("Test network fallback only") { Task { await sendWithExplicitMode(.networkOnly) } }.disabled(isSending)
                    Button("Run BOTH algorithms fingerprint-only") { Task { await runBothAlgorithms() } }.disabled(isSending)
                    Button("Run core attribution sequence") { Task { await runCoreSequence() } }.disabled(isSending)
                    Text("Regression buttons pass the send mode directly to the request; they do not depend on Picker state updating first.")
                        .font(.footnote).foregroundColor(.secondary)
                }

                Section(header: Text("Last request / response")) {
                    ScrollView { Text(logText).font(.system(.footnote, design: .monospaced)).frame(maxWidth: .infinity, alignment: .leading) }.frame(minHeight: 260)
                    Button("Copy Log") { UIPasteboard.general.string = logText }
                    Button("Clear Log") { logText = "" }
                }
            }
            .navigationBarTitle("Attribution Fingerprint Lab", displayMode: .inline)
            .task { await sendAutomaticOpenEventAfterLaunchDelay() }
            .onOpenURL { url in
                captureShortCode(from: url)
                Task { await sendAutomaticOpenEvent(reason: "deep_link") }
            }
            .alert(isPresented: $showResetAlert) {
                Alert(title: Text("Reset install identity?"), message: Text("This does not change either environment fingerprint algorithm."), primaryButton: .destructive(Text("Reset")) { installID = KeychainStore.shared.resetInstallID() }, secondaryButton: .cancel())
            }
        }
    }

    private func compare(_ pasted: String, _ app: String) -> String {
        let value = pasted.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        if value.isEmpty { return "WAITING FOR H5 VALUE" }
        return value == app.uppercased() ? "MATCH ✅" : "MISMATCH ❌"
    }

    private var modeHelp: String {
        switch mode {
        case .shortCodeAndFingerprint: return "Sends short_code + the currently selected fingerprint. Worker evaluates both matches independently."
        case .fingerprintOnly: return "Omits short_code and sends only the currently selected fingerprint."
        case .networkOnly: return "Omits short_code and hw_fingerprint. For an H5→App network fallback test, paste the SAME H5 navigator.userAgent above; Worker hashes IP + UA, so App UA alone will not reproduce an H5 click fingerprint."
        }
    }

    private func labeledValue(_ label: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 4) { Text(label).font(.caption).foregroundColor(.secondary); Text(value).font(.system(.footnote, design: .monospaced)) }
    }
    private func eventPreset(_ title: String, _ value: String) -> some View {
        Button(title) { eventType = value }
            .buttonStyle(.borderless)
    }

    @MainActor private func runHealth() async {
        isSending = true; defer { isSending = false }
        do { let result = try await AttributionClient.health(baseURL: workerBaseURL); appendLog("HEALTH HTTP \(result.httpStatus)\n\(result.body)") }
        catch { appendLog("HEALTH ERROR\n\(error.localizedDescription)") }
    }

    @MainActor private func sendCurrentEvent() async {
        isSending = true; defer { isSending = false }
        await send(result: selected, using: mode, eventTypeOverride: eventType, amountOverride: amount)
    }

    @MainActor private func sendWithExplicitMode(_ explicitMode: AttributionMode) async {
        isSending = true; defer { isSending = false }
        await send(result: selected, using: explicitMode, eventTypeOverride: eventType, amountOverride: amount)
    }

    @MainActor private func sendNamedEvent(_ name: String, amountOverride: Double) async {
        isSending = true; defer { isSending = false }
        await send(result: FingerprintLab.crossSurfaceV2, using: mode, eventTypeOverride: name, amountOverride: amountOverride)
    }

    @MainActor private func sendAutomaticOpenEventAfterLaunchDelay() async {
        guard !didSendAutomaticOpenEvent else { return }
        try? await Task.sleep(nanoseconds: 800_000_000)
        guard !didSendAutomaticOpenEvent else { return }
        await sendAutomaticOpenEvent(reason: "app_launch")
    }

    @MainActor private func sendAutomaticOpenEvent(reason: String) async {
        guard !isSending else {
            appendLog("AUTO APP EVENT SKIPPED\nAnother request is already in progress.")
            return
        }

        didSendAutomaticOpenEvent = true
        isSending = true
        defer { isSending = false }

        let hasShortCode = shortCodeCapturedThisLaunch && !shortCode.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        let automaticMode: AttributionMode = hasShortCode ? .shortCodeAndFingerprint : .fingerprintOnly
        appendLog("AUTO APP EVENT\nREASON \(reason)\nEVENT app_registration\nALGORITHM \(FingerprintLab.crossSurfaceV2.algorithmID)\nMODE \(automaticMode.rawValue)")
        await send(
            result: FingerprintLab.crossSurfaceV2,
            using: automaticMode,
            eventTypeOverride: "app_registration",
            amountOverride: 0
        )
    }

    @MainActor private func send(result r: FingerprintResult, using sendMode: AttributionMode, eventTypeOverride: String, amountOverride: Double) async {
        do {
            let result = try await AttributionClient.sendEvent(
                baseURL: workerBaseURL,
                eventType: eventTypeOverride,
                shortCode: shortCode,
                fingerprint: r.fingerprint,
                mode: sendMode,
                amount: amountOverride,
                currency: currency,
                networkUserAgent: h5NetworkUserAgent
            )
            let networkNote = sendMode == .networkOnly
                ? "\nNETWORK_UA_SOURCE \(h5NetworkUserAgent.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? "APP_REQUEST_HEADER (H5 match unlikely)" : "PASTED_H5_USER_AGENT")"
                : ""
            appendLog("DEVICE \(DeviceInfo.modelIdentifier) iOS \(UIDevice.current.systemVersion)\nALGORITHM \(r.algorithmID)\nCANONICAL \(r.canonicalString)\nHW \(r.fingerprint)\nMODE \(sendMode.rawValue)\(networkNote)\nEVENT \(eventTypeOverride)\nEVENT_ID \(result.eventID)\nHTTP \(result.httpStatus)\nSENT:\n\(result.sentPayload)\nRESPONSE:\n\(result.body)")
        } catch {
            appendLog("EVENT ERROR [\(r.algorithmID)]\n\(error.localizedDescription)")
        }
    }

    @MainActor private func runBothAlgorithms() async {
        isSending = true; defer { isSending = false }
        appendLog("=== BOTH ALGORITHMS START ===")
        await send(result: FingerprintLab.legacyApprox, using: .fingerprintOnly, eventTypeOverride: eventType, amountOverride: amount)
        try? await Task.sleep(nanoseconds: 800_000_000)
        await send(result: FingerprintLab.crossSurfaceV2, using: .fingerprintOnly, eventTypeOverride: eventType, amountOverride: amount)
        appendLog("=== BOTH ALGORITHMS END ===")
    }

    @MainActor private func runCoreSequence() async {
        isSending = true; defer { isSending = false }
        appendLog("=== CORE ATTRIBUTION SEQUENCE START ===")
        do {
            let health = try await AttributionClient.health(baseURL: workerBaseURL)
            appendLog("HEALTH HTTP \(health.httpStatus)\n\(health.body)")
        } catch {
            appendLog("HEALTH ERROR\n\(error.localizedDescription)")
        }
        await send(result: selected, using: .shortCodeAndFingerprint, eventTypeOverride: eventType, amountOverride: amount)
        try? await Task.sleep(nanoseconds: 800_000_000)
        await send(result: selected, using: .fingerprintOnly, eventTypeOverride: eventType, amountOverride: amount)
        try? await Task.sleep(nanoseconds: 800_000_000)
        await send(result: selected, using: .networkOnly, eventTypeOverride: eventType, amountOverride: amount)
        appendLog("=== CORE ATTRIBUTION SEQUENCE END ===")
    }

    private func captureShortCode(from url: URL) {
        guard url.scheme?.lowercased() == "attribtest" else { return }
        let components = URLComponents(url: url, resolvingAgainstBaseURL: false)
        if let code = components?.queryItems?.first(where: { $0.name == "short_code" || $0.name == "c" })?.value, !code.isEmpty {
            shortCode = code.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
            shortCodeCapturedThisLaunch = true
            appendLog("Captured short_code: \(shortCode)")
        }
    }
    private func appendLog(_ message: String) {
        let stamp = ISO8601DateFormatter().string(from: Date())
        logText = logText.isEmpty ? "[\(stamp)] \(message)" : logText + "\n\n[\(stamp)] \(message)"
    }
}
