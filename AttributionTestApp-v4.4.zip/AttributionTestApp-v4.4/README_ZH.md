# Attribution Test App v4.4

用 Xcode 打开 `AttributionTestApp.xcodeproj`，选择你的签名账号和真机后编译安装。

本版本的测试行为：

- App 正常启动约 0.8 秒后自动发送一次 `app_registration`。
- 从 H5 的 `attribtest://open` 深链进入时，App 先接收本次 Short Code，再自动发送事件。
- 深链启动发送 `Short Code + CROSS_SURFACE_V2`；普通安装后首次打开没有短码时发送 `CROSS_SURFACE_V2`。
- 自动事件每次生成新的 `event_id`。
- `Send View now`、`Send Register now`、`Send Purchase now` 固定使用 V2。
- 旧算法只保留用于诊断对比。

在 App 的 `Last request / response` 中检查实际请求和 Worker 返回结果。
